#include "link.h"
#include "node.h"
#include <iostream>
#include <fstream>
using namespace std;

link::link(int x)
{
    filos=NULL;
    value=x;
    right=NULL;
    left=NULL;
}

link::~link()
{
    //dtor
}

