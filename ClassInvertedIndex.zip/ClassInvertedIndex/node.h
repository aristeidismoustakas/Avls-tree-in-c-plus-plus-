#ifndef NODE_H
#define NODE_H
#include <iostream>
#include <fstream>

using namespace std;

class node
{
    public:
        node(int x);
        ~node();

        node *left;
        node *right;
        int value;

};

#endif // NODE_H
