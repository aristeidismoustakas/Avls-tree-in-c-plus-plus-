#include "ClassInvertedIndex.h"
#include "link.h"
#include "node.h"
#include <iostream>
#include <fstream>

using namespace std;

ClassInvertedIndex::ClassInvertedIndex()
{
    root=NULL;
}

ClassInvertedIndex::~ClassInvertedIndex()
{
    //dtor
}



int counter;//�������� ��� �� ���� �� ���� ������� ��� ��������� ����� ���� ��� ��������
//���� �� ���� ��� ������ pointer ��� ������ ���� ����� ����� �������� ��� right � ��� left ���
//��� �� �� �� �� ������ ����� ������������ �� ��� test
bool ClassInvertedIndex::insertlink(link* &root,int key)
{
    if(root==NULL) {
    root=new link(key);
    counter=0;
    }

    else
    {
        if(root->value>key) {
        insertlink(root->left,key);
        counter+=1;
        }
        else if(root->value<key) {
        insertlink(root->right,key);
        counter+=1;
        }
        else if(root->value==key) return false;
    }
    if(counter==2)
    {

        counter+=1;
        test(root);
    }
    return true;
}

link* ClassInvertedIndex::findlink(link *root,int key)
{
    if(root==NULL)
        return NULL;
    if(root->value==key)
        return root;
    if(root->value>key)
       return findlink(root->left,key);
    else
       return findlink(root->right,key);
}

link **parent;//������� ������ ��� ������ ���� ��������, ��� ������ �� ��� test
bool ClassInvertedIndex::deletelink(link * &root,int key)
{
    if (root==NULL) return false;
    link **child,*temp,*A;
    bool left;

if(key<root->value){
    child=&(root->left);
    parent=&root;
    left=true;
}else{
    child=&(root->right);
    parent=&root;
    left=false;

}
if((*child)->value==key)
{
    if((*child)->left==NULL) temp=(*child)->right;
    else if((*child)->right==NULL) temp=(*child)->left;
    else
    if(left){
      temp=(*child)->right;
      A=leftMostLeaf(temp);
      A->left=(*child)->left;
    }
    else{
        temp=(*child)->left;
        A=rightMostLeaf(temp);
        A->right=(*child)->right;
    }
    delete (*child);
    *child=temp;
    if(*parent!=NULL)
    test(*parent);
    if(*child!=NULL)
    test(*child);
    return true;
}
else return deletelink(*child,key);
}

void ClassInvertedIndex::deletelinkroot(link* &root)
{
     int tempVal;
     if(root->left==NULL && root->right==NULL)
        {root=NULL;
        return;}
    link *temp;
    if(root->left!=NULL) temp=rightMostLeaf(root->left);
    else
        if(root->right!=NULL) temp=leftMostLeaf(root->right);
    if(temp!=NULL)
    {
        tempVal=temp->value;
        deletelink(root,temp->value);
        root->value=tempVal;
    }
}

link* ClassInvertedIndex::leftMostLeaf(link *root)
{
    if(root==NULL) return NULL;
    if(root->left==NULL) return root;
    return leftMostLeaf(root->left);
}

link* ClassInvertedIndex::rightMostLeaf(link *root)
{
    if(root==NULL) return NULL;
    if(root->right==NULL) return root;
    return rightMostLeaf(root->right);
}

void ClassInvertedIndex::rightRot(link* &root)
{
   link *temp1,*temp2;
   temp1=root;
   temp2=root->left->right;
   root=root->left;
   root->right=temp1;
   temp1->left=temp2;
}

void ClassInvertedIndex::leftRot(link* &root)
{
    link *temp1,*temp2;
    temp1=root;
    temp2=root->right->left;
    root=root->right;
    root->left=temp1;
    temp1->right=temp2;
}

void ClassInvertedIndex::rightLeftRot(link* &root)
{
    rightRot(root->right);
    leftRot(root);
}

void ClassInvertedIndex::leftRightRot(link* &root)
{
    leftRot(root->left);
    rightRot(root);
}

int ClassInvertedIndex::Height(link* root)
{
    int left, right;

     if(root==NULL)
         return 0;
     left = Height(root->left);
     right = Height(root->right);
  if(left > right)
            return left+1;
         else
            return right+1;
}

void ClassInvertedIndex::test(link *&root)
{
        int a=Height(root->left);
        int b=Height(root->right);
    if(a-b==2)
    {
        if(root->left->right==NULL) rightRot(root);
        else leftRightRot(root);

        }
    else
        if(a-b==-2)
    {
        if(root->right->left==NULL) leftRot(root);
        else rightLeftRot(root);
    }

}




bool ClassInvertedIndex::insertnode(node* &root,int key)
{
    if(root==NULL){ root=new node(key);
    counter=0;}
    else
    {
        if(root->value>key) {
        insertnode(root->left,key);
        counter+=1;
        }
        else if(root->value<key) {
        insertnode(root->right,key);
        counter+=1;
        //testnode(root);
        }
        else if(root->value==key) return false;
         if(counter==2)
        {

                counter+=1;
                testnode(root);
        }
    }

    return true;
}

node* ClassInvertedIndex::findnode(node *root,int key)
{
    if(root==NULL)
        return NULL;
    if(root->value==key)
        return root;
    if(root->value>key)
       return findnode(root->left,key);
    else
       return findnode(root->right,key);
}

node** nodeParent;
bool ClassInvertedIndex::deletenode(node * &root,int key)
{
    if (root==NULL) return false;
    node **child,*temp,*A;
    bool left;

if(key<root->value){
    child=&(root->left);
    nodeParent=&(root);
    left=true;
}else{
    child=&(root->right);
    nodeParent=&(root);
    left=false;

}
if((*child)->value==key)
{
    if((*child)->left==NULL) temp=(*child)->right;
    else if((*child)->right==NULL) temp=(*child)->left;
    else
    if(left){
      temp=(*child)->right;
      A=leftMostLeaf(temp);
      A->left=(*child)->left;
    }
    else{
        temp=(*child)->left;
        A=rightMostLeaf(temp);
        A->right=(*child)->right;
    }
    delete (*child);
    *child=temp;
    if(*nodeParent!=NULL)
    testnode(*nodeParent);
    if(*child!=NULL)
    testnode(*child);
    return true;
}
else  return deletenode(*child,key);
}

void ClassInvertedIndex::deletenoderoot(node* &root)
{
    int tempVal;
    if((root->left==NULL) && (root->right==NULL))
        {root=NULL;
        return;}
        node *temp;
        if(root->left!=NULL)
        temp=(rightMostLeaf(root->left));
        else
        if(root->right!=NULL)
           temp=(leftMostLeaf(root->right));
        if(temp!=NULL){
        {
            tempVal=temp->value;
            deletenode(root,temp->value);
            root->value=tempVal;
        }

}
}

node* ClassInvertedIndex::leftMostLeaf(node *root)
{
    if(root==NULL) return NULL;
    if(root->left==NULL) return root;
    return leftMostLeaf(root->left);
}

node* ClassInvertedIndex::rightMostLeaf(node *root)
{
    if(root==NULL) return NULL;
    if(root->right==NULL) return root;
    return rightMostLeaf(root->right);
}

void ClassInvertedIndex::rightRotnode(node* &root)
{
   node *temp1,*temp2;
   temp1=root;
   temp2=root->left->right;
   root=root->left;
   root->right=temp1;
   temp1->left=temp2;
}

void ClassInvertedIndex::leftRotnode(node* &root)
{
    node *temp1,*temp2;
    temp1=root;
    temp2=root->right->left;
    root=root->right;
    root->left=temp1;
    temp1->right=temp2;
}

void ClassInvertedIndex::rightLeftRotnode(node* &root)
{
    rightRotnode(root->right);
    leftRotnode(root);
}

void ClassInvertedIndex::leftRightRotnode(node* &root)
{
    leftRotnode(root->left);
    rightRotnode(root);
}

int ClassInvertedIndex::Heightnode(node* root)
{
    int left, right;

     if(root==NULL)
         return 0;
     left = Heightnode(root->left);
     right = Heightnode(root->right);
  if(left > right)
            return left+1;
         else
            return right+1;
}

void ClassInvertedIndex::testnode(node *&root)
{
        int a=Heightnode(root->left);
        int b=Heightnode(root->right);
    if(a-b==2)
    {
        if(root->left->right==NULL) rightRotnode(root);
        else leftRightRotnode(root);
        }
    else
        if(a-b==-2)
    {
        if(root->right->left==NULL) leftRotnode(root);
        else rightLeftRotnode(root);
    }
    else
        return;

}

//����������� ��� ��� ������� ��� �� commands.txt

void ClassInvertedIndex::deleteboth(link * &root,int x,int y)
{
    //��������� ��� ��� ������ DELETE_LINK x y
    //��������� �� y ��� ���� ������ ��� x ��� ��������� �� x ��� ���� ������ ��� y
    //�� ���� ��� ��������� ������ link ��� ���� ������ �� ���������
    link *a,*b;
    node *a_links,*b_links;
    a=findlink(root,x);
    b=findlink(root,y);
    if((a!=NULL)&&(b!=NULL))
    {
        a_links=findnode(a->filos,y);
        b_links=findnode(b->filos,x);

      if(a_links!=NULL&&b_links!=NULL)
      {
        if(a->filos!=NULL&&b->filos!=NULL)
        {
            if(a->value==b->value) return;
            //������ �� ��� �� �������� ����
            if(a->filos->value==y) deletenoderoot(a->filos);
            else deletenode(a->filos,y);

            if(b->filos->value==x) deletenoderoot(b->filos);
            else deletenode(b->filos,x);

            if(a->filos==NULL)
            {
            if(root->value==x) deletelinkroot(root);
            else deletelink(root,a->value);
            }
            if(b->filos==NULL)
            {
            if(root->value==y) deletelinkroot(root);
            else deletelink(root,b->value);
            }
        }
      }
  }
}

void ClassInvertedIndex::neos(link* &root,int x,int y)
{
    //��������� ��� ��� ������ INSERT_LINK x y
    //������� ����� ������ ��� x �� y ��� ����� ������ ��� y �� x
    //�� ��� �������� �� link x � �� link y �� ����������
    insertlink(root,x);
    insertlink(root,y);
    insertnode(findlink(root,x)->filos,y);
    insertnode(findlink(root,y)->filos,x);
}

void ClassInvertedIndex::nodecounter(node* root)
{
    if(root==NULL) return;
    nodecounter(root->left);
    counter+=1;
    nodecounter(root->right);
}

void ClassInvertedIndex::writeindex(link *root,ofstream &k)
{
if (root==NULL)
return;
writeindex(root->left,k);
counter=0;
nodecounter(root->filos);
k<<root->value<<" "<<counter<<"      ";
counter=0;
inorder(root->filos,k);
k<< endl;
writeindex(root->right,k);
}

void ClassInvertedIndex::inorder(node *root,ofstream &k)
{
if (root==NULL)
return;
inorder(root->left,k);
k<<root->value<<" ";
inorder(root->right,k);
}
