#include "node.h"
#include <iostream>
using namespace std;

node::node(int x)
{
    value=x;
    left=NULL;
    right=NULL;
}

node::~node()
{
    //dtor
}

